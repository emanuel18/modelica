use strict;
use warnings;
use Data::Dumper;
use Graph::Undirected;
use constant N => 10;
use constant PRINT => 1;
use lib '/Users/emanuel/Documents/personal/facultad/causalize/4';
use Array::Utils qw(:all);

use Exporter qw(import);
our @EXPORT_OK = qw( process_mn_with_cycle_and_index );
use constant DEBUG => 0;

 our $init_data1 = {
    fi => {
        ran => { # rango del for
            init => 1,
            end  => N-1,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index    => "",
                constant => ""
            },
            b => {
                index    => "",
                constant => [1]
            },
        }, 
    },
    gi => {
        ran => {
            init => 1,
            end  => N-1,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index => {
                    0 => {
                        init => 1,
                        end  => N-1,
                        next => 1
                    },
                    1 => {
                        init => 2,
                        end  => N,
                        next => 1
                    }
                },
                constant => ""
            },
            b => {
                index    => "",
                constant => ""
            }
        }, 
    },
    fn => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var_info => {
            a => [ N ],
            b => [ N ]
        } 
    },
    gn => {
        ran => "",
        var_info => {
            a => [ N ],
            b => [ N ]
        } 
    },
};


our $macro_node1 = [
          'a18',
          'b18',
          'fi',
          'gi'
];


our $graph_info1 = {
          'vars' => {
                      'b18' => 'b',
                      'a18' => 'a',
                      'c' => 'c',
                      'a9' => 'a',
                      'b9' => 'b',
                      'b10' => 'b',
                      'a10' => 'a'
                    },
          'eqs' => {
                     'h1' => '',
                     'fn' => '',
                     'fi' => '',
                     'gn' => '',
                     'gi' => '',
                     'h2' => '',
                     'h3' => ''
                   }
};

our $macro_node2 = [
          'a9',
          'b9',
          'fn',
          'gn'
        ];

&process_internal_mn();

sub process_internal_mn {

    my $mn = $macro_node1;
    my $init_data = $init_data1;
    my $graph_info = $graph_info1;
    resolve_internal_macro_node($mn, $init_data, $graph_info);
}


sub resolve_internal_macro_node {
    my $cycle_nodes = shift;
    my $data = shift;
    my $graph_info = shift;
    my $result;

    my @all_equations = keys %{$graph_info->{eqs}};
    my @all_variables = keys %{$graph_info->{vars}};

    my @equations = intersect(@all_equations, @{$cycle_nodes});
    my @variables = intersect(@all_variables, @{$cycle_nodes});


    # warn "equations: " . Dumper(@equations);
    # warn "variables: " . Dumper(@variables);
# return;
    my $val_index = 0;

    my $ran_eq = $data->{$equations[0]}->{ran};

    my $origin_vars;
    foreach my $v (@variables) {
        my $o_var = $graph_info->{vars}->{$v};

        # dentro de un for
        if (ref ($data->{$equations[0]}->{var_info}->{$o_var}) eq 'HASH') {
            $origin_vars->{$o_var} = $data->{$equations[0]}->{var_info}->{$o_var}->{constant} || ""; 
        } else {
             $origin_vars->{$o_var} = $data->{$equations[0]}->{var_info}->{$o_var} || ""; 
        }
       

    }

    my $ordered_ran;
    # my $ordered_variables;
    my $ordered_var_info;

    # me fijo si las funciones estan dentro de un for
    if ($ran_eq) {
        my $init;
        my $end;
        my $next;
        foreach my $e (@equations) {

            foreach my $v (@variables) {
                my $real_var = $graph_info->{vars}->{$v};
                # print "real_var $v: $real_var\n";
                my $diff_index = $data->{$e}->{var_info}->{$real_var}->{index};
                my $ran_eq = $data->{$e}->{ran}; # esto me dice si la eq esta dentro de un for
                
                if ($diff_index) {
                    # print "ran_eq : " . Dumper($ran_eq) . " \n";
                    # print "diff_index $e $v $real_var: " . Dumper($diff_index) . " \n";

                    foreach my $val (keys %{$diff_index}) {
                        # print "diff_index $e $v $real_var val_key $val_index: \n";

                        if ($val_index > 0) {
                            die "El mismo for no puede contener variables con indices < y > que i" if ($val < 0);

                        } 
                        elsif ($val_index < 0) {
                            die "El mismo for no puede contener variables con indices < y > que i" if ($val > 0);
                        } 
                        else {
                            $val_index = $val;
                        }

                    }
                    if ($val_index > 0) {
                        $init = $ran_eq->{end};
                        $end  = $ran_eq->{init};
                        $next = -1;

                    } 
                    else {
                        $init = $ran_eq->{init};
                        $end  = $ran_eq->{end};
                        $next = 1;
                    }

                }
            }
        }

        $ordered_ran = {
            init => $init,
            end  => $end,
            next => $next,
            vars => $ran_eq->{vars}
        };

        $ordered_var_info = $origin_vars;
        # $ordered_variables = \@origin_vars;

    } 
    else {

        # my $real_variables;
        foreach my $e (@equations) {
            # print "\t\tecuacion: $e\n";
            foreach my $v (@variables) {
                my $real_var = $graph_info->{vars}->{$v};
                # print "real_var $v: $real_var\n";
                my $indices = $data->{$e}->{var_info}->{$real_var};
                # print "indices:" . Dumper($indices) ."\n";
                my @vars;
                if ($indices) {
                    foreach my $ind (@{$indices}) {
                        # print "ind:" . Dumper($ind) ."\n";
                        push @vars, $ind;
                    }
                }

                $ordered_var_info->{$real_var} = \@vars;
                # $ordered_variables->{$real_var} = \@vars;

            }
        }

        $ordered_ran = "";
    }

    my $ordered_graph = {
        equations  => \@equations,
        var_info  => $ordered_var_info,
        # variables  => $ordered_variables,
        ran        => $ordered_ran 
    };
    
    print "ordered_graph: " . Dumper($ordered_graph);

    return $ordered_graph;

}

# my $causalized = {
#     ran        => {
#         init => N-1,
#         end  => 1,
#         next => 1,
#         vars => [a,b]
#     },
#     equations  => [fi,gi]
#     var_info  => {
#       a => "",
#       b => "",
#     }
# }


1;