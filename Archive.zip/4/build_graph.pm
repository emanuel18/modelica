use strict;
use warnings;
use Data::Dumper;
use Graph::Undirected;
use constant N => 10;
use constant PATH_DOT => "/Users/emanuel/Documents/personal/facultad/causalize/4/bg.dot";
use constant PATH_PNG => "/Users/emanuel/Documents/personal/facultad/causalize/4/bg.png";
use Scalar::Util 'looks_like_number';  
use Exporter qw(import);
our @EXPORT_OK = qw(build_graph build_png );
use constant DEBUG => 0;

# a[N], b[N], c
# for i in 1:N-2 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]-a[i+1]=5;  //gi
# end for;
#
# a[N-1]-b[N-1]=8;  //fn
# a[N-1]+b[N-1]=5;  //gn
#
# a[N] = 22             //h1
# a[N] + b[N] + c = 22  //h2
# c = 10                //h3
our $init_data1 = {
    fi => {
        ran => { # rango del for
            init => 1,
            end  => N-2,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index    => "",
                constant => ""
            },
            b => {
                index    => "",
                constant => ""
            },
        }, 
    },
    gi => {
        ran => {
            init => 1,
            end  => N-2,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index => {
                    0 => {
                        init => 1,
                        end  => N-2,
                        next => 1
                    },
                    1 => {
                        init => 2,
                        end  => N-1,
                        next => 1
                    }
                },
                constant => ""
            },
            b => {
                index    => "",
                constant => ""
            }
        }, 
    },
    fn => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var_info => {
            a => [ N-1 ],
            b => [ N-1 ]
        } 
    },
    gn => {
        ran => "",
        var_info => {
            a => [ N-1 ],
            b => [ N-1 ]
        } 
    },
    h1 => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var_info => {
            a => [ N ],
        } 
    },
    h2 => {
        ran => "",
        var_info => {
            a => [ N ],
            b => [ N ],
            c => ""
        } 
    },
    h3 => {
        ran => "",
        var_info => {
            c => ""
        } 
    },
};


&main();

sub main {
    my $data = build_graph($init_data1);
my $aa;
if (defined $aa) {print "aaaa: $aa";}


    # build_png($data->{graph});
}

sub build_graph {
    my $init_data = shift;
# print Dumper(keys %{$init_data1->{gi}->{var_info}->{a}});
    my $graph = Graph::Undirected->new();

    my $graph_info;
    foreach my $eq (keys %{$init_data}) {
        $graph->add_vertex( $eq );
        print "eq: $eq \n" if DEBUG;
        $graph_info->{eqs}->{$eq} = ""; 

        foreach my $var (keys %{$init_data->{$eq}->{var_info}}) {

            # este es el caso cuando el rango del for es vacio: fn gn
            if (!$init_data->{$eq}->{ran}) {

                my $var_data = $init_data->{$eq}->{var_info}->{$var};
                # print "var_data : $var_data\n";

                if ( $var_data ) {
                    foreach my $index (@{$var_data}) {

                        # my $index = $data->{index};
                        # my $end  = $data->{end};

                        if ($index) {
                            looks_like_number($index);

                            my $new_var = $var . $index;
                            $graph_info->{vars}->{$new_var} = $var; 
                            # $graph_info->{$new_var} = $var;

                            $graph->add_vertex( $new_var );
                            print "\t11var: $new_var\n" if DEBUG;

                            $graph->add_edge( $eq, $new_var );
                        } else {
                            # caso de una variable como c[N]
                            my $new_var = $var;
                            $graph_info->{vars}->{$new_var} = $var; 
                            # $graph_info->{$new_var} = $var;

                            $graph->add_vertex( $new_var );
                            # print "\t12var: $new_var\n";
                            $graph->add_edge( $eq, $new_var );
                        }
                    }
                }
                else { # este es el caso de c
                    my $new_var = $var;
                    $graph_info->{vars}->{$new_var} = $var; 
                    # $graph_info->{$new_var} = $var;

                    $graph->add_vertex( $new_var );
                    print "\t13var: $new_var\n" if DEBUG;
                    $graph->add_edge( $eq, $new_var );
                }

            } 
            else { # este es el caso cuando esta dentro del for

                    my $ran = $init_data->{$eq}->{ran};
                    my $init = $ran->{init};
                    my $end  = $ran->{end};

                    my $new_var = $var . $init;
                    $new_var .= $end if ($init != $end);
                    $graph_info->{vars}->{$new_var} = $var; 
                    # $graph_info->{$new_var} = $var;

                    $graph->add_vertex( $new_var );
                    print "\t3var: $new_var\n" if DEBUG;
  
                    $graph->add_edge( $eq, $new_var );
            }
        }

    }
    warn Dumper($graph_info) if DEBUG;
    my $data = {
        graph       => $graph,
        graph_info  => $graph_info
    };

    return $data;
}

# graph_info = {
#           'eqs' => {
#                      'h2' => '',
#                      'fn' => '',
#                      'gn' => '',
#                      'h3' => '',
#                      'gi' => '',
#                      'fi' => '',
#                      'h1' => ''
#                    },
#           'vars' => {
#                       'b18' => 'b',
#                       'c' => 'c',
#                       'b10' => 'b',
#                       'a18' => 'a',
#                       'a10' => 'a',
#                       'a9' => 'a',
#                       'b9' => 'b'
#                     }
#         };

sub build_png {
    my $graph = shift;

    my $g = "graph G{   
        subgraph cluster0{
        label = \"Equations\"; 
        edge [style=invis];
        ";


    my @all_nodes = $graph->vertices;
    my @ec;
    my @var;
    foreach my $node (@all_nodes) {

        if ($node =~ /f/ || $node =~ /g/ || $node =~ /h/ || $node =~ /k/) {
            push @ec, $node;
        } else {
            push @var, $node;
        }
    }

    my $ecs = join ' -- ', sort @ec;
    my $vars = join ' -- ', sort @var;

    $g .= $ecs . ";\n";
    $g .= "        }
        subgraph cluster1{
        label = \"Unknowns\";
        edge [style=invis];
        ";
    $g .= $vars . ";\n";


    $g .= "        }
        edge [constraint=false];\n";

    my @all_edges = $graph->edges;
    foreach my $e (@all_edges) {
        my @e = @$e;
        my $edge = "        " . $e[0] . " -- " . $e[1] . ";\n";
        $g .= $edge;
    }
    $g .= "}";


    open( my $output_file, '>:utf8', PATH_DOT) or die "Can't open";
    print $output_file $g;
    close $output_file;

    my $command = "dot -Tpng " . PATH_DOT . " -o " . PATH_PNG;

    my $output = `$command 2>&1`;
}

1;
        # fi -- gi -- fn -- gn;
        # a19 -- b19 -- a10 -- b10;

#         fi -- gi -- fn -- gn -- h1 -- h2 -- h3;
#         a18 -- b18 -- a9 -- b9 -- a10 -- b10 -- c;