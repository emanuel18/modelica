package causalize;

use strict;
use warnings;
use Data::Dumper;
use Graph::Undirected;
use constant N => 10;
use constant PRINT => 1;
use build_graph qw(:build_graph);
use process_internal_macro_node qw(:resolve_internal_macro_node);
use util qw(:find_variable_in_graph);
use Array::Utils qw(:all);

# a[N], b[N]
# for i in 1:N-1 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]-a[i+1]=5;  //gi
# end for;

# a[N]-b[N]=8;  //fn
# a[N]+b[N]=5;  //gn

 our $init_data1 = {
    fi => {
        ran => { # rango del for
            init => 1,
            end  => N-1,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index    => "",
                constant => ""
            },
            b => {
                index    => "",
                constant => ""
            },
        }, 
    },
    gi => {
        ran => {
            init => 1,
            end  => N-1,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index => {
                    0 => {
                        init => 1,
                        end  => N-1,
                        next => 1
                    },
                    1 => {
                        init => 2,
                        end  => N,
                        next => 1
                    }
                },
                constant => ""
            },
            b => {
                index    => "",
                constant => ""
            }
        }, 
    },
    fn => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var_info => {
            a => [ N ],
            b => [ N ]
        } 
    },
    gn => {
        ran => "",
        var_info => {
            a => [ N ],
            b => [ N ]
        } 
    },
};


# a[N], b[N], c
# for i in 1:N-2 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]-a[i+1]=5;  //gi
# end for;
#
# a[N-1]-b[N-1]=8;  //fn
# a[N-1]+b[N-1]=5;  //gn
#
# a[N] = 22             //h1
# a[N] + b[N] + c = 22  //h2
# c = 10                //h3
our $init_data2 = {
    fi => {
        ran => { # rango del for
            init => 1,
            end  => N-2,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index    => "",
                constant => ""
            },
            b => {
                index    => "",
                constant => ""
            },
        }, 
    },
    gi => {
        ran => {
            init => 1,
            end  => N-2,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index => {
                    0 => {
                        init => 1,
                        end  => N-2,
                        next => 1
                    },
                    1 => {
                        init => 2,
                        end  => N-1,
                        next => 1
                    }
                },
                constant => ""
            },
            b => {
                index    => "",
                constant => ""
            }
        }, 
    },
    fn => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var_info => {
            a => [ N-1 ],
            b => [ N-1 ]
        } 
    },
    gn => {
        ran => "",
        var_info => {
            a => [ N-1 ],
            b => [ N-1 ]
        } 
    },
    h1 => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var_info => {
            a => [ N ],
        } 
    },
    h2 => {
        ran => "",
        var_info => {
            a => [ N ],
            b => [ N ],
            c => ""
        } 
    },
    h3 => {
        ran => "",
        var_info => {
            c => ""
        } 
    },
};


&causalize();

sub causalize {

    # warn Dumper($data);
    my $init_data = $init_data2;
    my $data = build_graph($init_data);
    my $graph = $data->{graph};
    my $graph_info = $data->{graph_info};

    warn "graph_info: " . Dumper($graph_info) . "\n";
    # obtengo todas los nodos del grafo
    # my @all_nodes = $graph->vertices;
    # @all_nodes = (fi,gi,fn,gn,ai,bi,an,bn);

    my $all_macro_node = get_macro_node($graph, $init_data, $graph_info);
    # warn "all_macro_node: " . Dumper($all_macro_node) . "\n";
    # return;

    my @internal_macro_node_ordered;

    # ordeno internamente c/u de los macro node
    foreach my $mn (@{$all_macro_node}) {
        # warn "macro node: " . Dumper($mn) . "\n";
        # warn "graph_info: " . Dumper($graph_info) . "\n";
        # esto me devuelve c/u de los grafos ordenados
        my $mn_ordered = resolve_internal_macro_node($mn, $init_data, $graph_info);
        $mn_ordered->{name} = join(',', @{$mn});

        # warn "macro node: " . Dumper($mn) . "\n";
        # warn "mn_ordered: " . Dumper($mn_ordered) . "\n";

        push @internal_macro_node_ordered, $mn_ordered;
    }


    # ahora tengo que ordenarlos externamente, tomo un macro nodo y busco cual es el orden 
    # en el que debe resolverse
    # my $ordered_graph = ordered_external_macro_node(\@internal_macro_node_ordered, $init_data);

    warn "internal_macro_node_ordered: " . Dumper(@internal_macro_node_ordered) . "\n";

    # warn "ordered_graph: " . Dumper($ordered_graph) . "\n";
    
    return;




    # my $all_cycles;
    # my $i=1;
    # my @ordered_inside_cycle;
    # while (my @cycle_nodes = $graph->find_a_cycle) {
    #     # warn "Ciclo: " . Dumper(@cycle) . "\n";

    #     $graph = $graph->delete_cycle(@cycle_nodes);
    #     my $cycle_ordered = resolve_macro_node(\@cycle_nodes, $init_data, $graph_info);
    #     $cycle_ordered->{name} = $i;

    #     push @ordered_inside_cycle, $cycle_ordered;
    #     $i++;
    # }


    # warn "ordered_inside_cycle: " . Dumper(@ordered_inside_cycle) . "\n";

    # my $ordered_graphs = ordered_external_macro_node(\@ordered_inside_cycle, $init_data);

}

# devuelve todos los macro nodos
# si estan dentro de un ciclo es un macronodo
# si se puede causalizar es un macronodo
sub get_macro_node {
    my $graph = shift;#warn "graph: " . Dumper($graph) . "\n";
    my $data = shift;#warn "data: " . Dumper($data) . "\n";
    my $graph_info = shift;#warn "graph_info: " . Dumper($graph_info) . "\n";

    my @macro_node;
    while (my @cycle_nodes = $graph->find_a_cycle) {
        # @cycle_nodes = sort @cycle_nodes;
        my @cn = sort @cycle_nodes;
        # warn "Ciclo: " . Dumper(@cn) . "\n";
        push @macro_node, \@cn;

        $graph = $graph->delete_cycle(@cycle_nodes);
    }

    my @vertices = $graph->vertices;
    foreach my $v (@vertices) {
        if ($graph->degree($v) && $graph->degree($v) == 1) {
            # print "v es $v\n";

            my @successors = $graph->successors($v);
            # como es de grado 1 el vertice solo tiene un sucesor
            my $v2 = shift(@successors);
            # print " successors: " . $v2 ." \n\n";
            my @node = ($v,$v2);
            @node = sort(@node);
            push @macro_node, \@node;
            # push @macro_node, [$v, $v2];
            die "Can not delete edge" unless($graph->delete_edge($v,$v2));
            die "Can not delete vertices" unless($graph->delete_vertices($v,$v2));
        }
    }

    print "\nmacro_node: " . Dumper(@macro_node);

    return \@macro_node;
}

# sub get_test_data {

#     my $data = {
#         init_data1 => $init_data1,
#         init_data2 => $init_data2,
#     };

#     return $data;
# }

1;