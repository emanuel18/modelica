use strict;
use warnings;
use Data::Dumper;
use Graph::Undirected;
use constant M => 10;
use constant PRINT => 1;
use build_graph qw(:build_graph);
use util qw(:find_variable_in_graph);
use Array::Utils qw(:all);

use Exporter qw(import);
our @EXPORT_OK = qw( process_mn_with_cycle );
use constant DEBUG => 0;


# a[N], b[N], c
# for i in 1:N-2 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]-a[i+1]=5;  //gi
# end for;
#
# a[N-1]-b[N-1]=8;  //fn
# a[N-1]+b[N-1]=5;  //gn
#
# a[N] = 22             //h1
# a[N] + b[N] + c = 22  //h2
# c = 10                //h3
our $init_data1 = {
    fi => {
        ran => { # rango del for
            init => 1,
            end  => N-2,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index    => "",
                constant => ""
            },
            b => {
                index    => "",
                constant => ""
            },
        }, 
    },
    gi => {
        ran => {
            init => 1,
            end  => N-2,
            vars => ['a','b']
        },
        var_info => {
            a => {
                index => {
                    0 => {
                        init => 1,
                        end  => N-2,
                        next => 1
                    },
                    1 => {
                        init => 2,
                        end  => N-1,
                        next => 1
                    }
                },
                constant => ""
            },
            b => {
                index    => "",
                constant => ""
            }
        }, 
    },
    fn => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var_info => {
            a => [ N-1 ],
            b => [ N-1 ]
        } 
    },
    gn => {
        ran => "",
        var_info => {
            a => [ N-1 ],
            b => [ N-1 ]
        } 
    },
    h1 => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var_info => {
            a => [ N ],
        } 
    },
    h2 => {
        ran => "",
        var_info => {
            a => [ N ],
            b => [ N ],
            c => ""
        } 
    },
    h3 => {
        ran => "",
        var_info => {
            c => ""
        } 
    },
};

our $macro_nodes1 = [
        {
          'equations' => [
                           'fi',
                           'gi'
                         ],
          'ran' => {
                     'init' => 8,
                     'vars' => [
                                 'a',
                                 'b'
                               ],
                     'end' => 1,
                     'next' => -1
                   },
          'var_info' => {
                          'a' => '',
                          'b' => ''
                        },
          'name' => 'a18,b18,fi,gi'
        },
        {
          'var_info' => {
                          'a' => [
                                   9
                                 ],
                          'b' => [
                                   9
                                 ]
                        },
          'name' => 'a9,b9,fn,gn',
          'equations' => [
                           'fn',
                           'gn'
                         ],
          'ran' => ''
        }, 
        {
          'var_info' => {
                          'c' => []
                        },
          'name' => 'c,h3',
          'equations' => [
                           'h3'
                         ],
          'ran' => ''
        },{
          'ran' => '',
          'equations' => [
                           'h2'
                         ],
          'name' => 'b10,h2',
          'var_info' => {
                          'b' => [
                                   10
                                 ]
                        }
        },{
          'name' => 'a10,h1',
          'var_info' => {
                          'a' => [
                                   10
                                 ]
                        },
          'ran' => '',
          'equations' => [
                           'h1'
                         ]
        }
];


&main1();

sub main1 {

    # my $a = {
    #     b => "",
    #     c => []
    # };
    # if ($a->{b}) {
    #     print "b es\n";
    # }
    # if ($a->{c}){
    #     my $c = $a->{c};
    #     print "c es\n";
    #     print "arr c es\n" if @{$c};
    # }
    # foreach my $i (keys %{$a}) {
    #     print "i $i if: " . Dumper($a->{$i}) if ($a->{$i});
    # }

    my $data = $init_data1;
    my $macro_nodes = $macro_nodes1;
    sort_macro_nodes($macro_nodes,$data);

}

# este es el caso en donde tengo una ecuacion causaliza con 
# una variable que es un que pertenece a un arreglo. Ej.: a[10]



# esta es el caso en donde lo que tengo que analizar es un macro nodo
# dentro de un for en donde un indice es del tipo i+1 o i-1
sub sort_macro_nodes {
    my $macro_nodes = shift;
    my $data = shift;

    my @tmp_mn = @{$macro_nodes};
    # my $node_to_be_ordered = shift(@tmp_mn);# tomo el primer elemento para ordenar
    # $node_to_be_ordered = shift(@tmp_mn);# tomo el primer elemento para ordenar
# print "node_to_be_ordered:" . Dumper($node_to_be_ordered);
# return;
    # my $var_info = shift;

    my @order = ();
    # warn " data: " . Dumper($data) . "\n";
    # print "\n\n HASH eq: $eq var_info:" . Dumper($var_info) . "\n";

    # recorro los indices, normalmente solo tiene un indice 
    # del tipo i+1 o i-1
    foreach my $node_to_be_ordered (@tmp_mn) {
        print "\n\n\n\n####################Nodo a ordenar eq: " . Dumper($node_to_be_ordered) . " \n";
        foreach my $eq (@{$node_to_be_ordered->{equations}}) {
            print "######Analizando eq: $eq \n";

            my $data_vars = $data->{$eq}->{var_info};
            # print "\tdata_vars:" . Dumper($data_vars) . " \n";
            foreach my $var (keys %{$data_vars}) {
                my $var_info_var = $data_vars->{$var};print "var_info_var: " . Dumper($var_info_var) . " ref: " . ref($var_info_var) . "\n";

                # print "\tAnalizando var_info: ". Dumper($var_info_var->{index}) ."\n";
                # print "\tAnalizando vars->{var}: ". Dumper($data_vars->{$var}) ."\n";
                # print "\n\nAnalizando eq: $eq var_info_var:" .Dumper($var_info_var) . "\n";
                
                # print "\tref: " . ref($var_info_var->{index}) . "\n";

                # var_info => {
                #     a => {
                #         index => {
                #             0 => {# si esto es vacio uso el rango por defecto, sino tomo este, 0 es i
                #                 init => 1,
                #                 end  => N,
                #             },
                #             1 => {# esto quiere decir que el indice es i+1
                #                 init => 2,
                #                 end  => N+1,
                #             },
                #         },
                #         constant => [1]
                #     },
                #     b => {
                #         index    => "",
                #         constant => [1]
                #     },
                #     c => "",
                #     d => {
                #         constant => [1]
                #     },
                # },
                # si es un hash es xq es un i+1, i-1, etc. distinto a i 
                # if (ref($var_info_var) eq 'HASH' && defined ($var_info_var->{index}) && ref($var_info_var->{index}) eq 'HASH') {
                if (ref($var_info_var) eq 'HASH' && defined $var_info_var->{index}) {
                    sort_macro_node_with_cycle(
                        eq          => $eq,
                        var         => $var,
                        node_to_be_ordered => $node_to_be_ordered,
                        macro_nodes => $macro_nodes,
                        data        => $data,
                        order       => \@order
                    );

                    # este es el caso 
                    #     d => {
                    #         constant => [1]
                    #     },
                    if (defined ($var_info_var->{constant}) && ref($var_info_var->{constant}) eq 'ARRAY') {
                        foreach my $cons (@{$var_info_var->{constant}}) {
                            foreach my $other_node (@{$macro_nodes}) {
                                if(find_variable_in_graph($other_node,$var,$cons)) {
                                    push @order, $node_to_be_ordered->{name} . " -> " . $other_node->{name};
                                    # print "\t1debe resolverse: " . $other_node->{name} . " antes de:" . $node_to_be_ordered->{name} . "\n" if (PRINT);
                                }
                            }

                        }
                    }
                }
                # var_info => {
                #     a => [ N ], 
                #     b => [ N, 2 ],
                # } 
                # aca analizo a y b
                elsif (defined ($var_info_var) && ref($var_info_var) eq 'ARRAY') {

                    sort_macro_node_without_cycle(
                        eq          => $eq,
                        var         => $var,
                        node_to_be_ordered => $node_to_be_ordered,
                        macro_nodes => $macro_nodes,
                        data        => $data,
                        order       => \@order
                    );
                }
                else {
                    sort_macro_node_without_cycle(
                        eq          => $eq,
                        var         => $var,
                        node_to_be_ordered => $node_to_be_ordered,
                        macro_nodes => $macro_nodes,
                        data        => $data,
                        order       => \@order
                    );
                }

            }
            print "####################fin ecuacion eq: $eq \n\n";
        }
    }
    print Dumper(@order);

    return @order;
}



sub sort_macro_node_with_cycle {
    my %args = (
        eq            => undef,
        var           => undef,
        node_to_be_ordered => undef,
        macro_nodes   => undef,
        data          => undef,
        order         => undef,
        @_,
    );

    my $eq          = $args{eq};
    my $var         = $args{var};
    my $node_to_be_ordered = $args{node_to_be_ordered};
    my $macro_nodes = $args{macro_nodes};
    my $data        = $args{data};
    my $order       = $args{order};
    
    my $data_vars = $data->{$eq}->{var_info};
    my $var_info_var = $data_vars->{$var};


    my $var_index = $var_info_var->{index};
    warn "hash var_index: " . Dumper($var_index) . "\n";
    # print "\n\n HASH eq: $eq var_info_var:" . Dumper($var_info) . "\n";

    # recorro los indices, normalmente solo tiene un indice 
    # del tipo i+1 o i-1
    if(ref($var_index) eq 'HASH') {
        foreach my $index (keys %{$var_index}) {
            next if ($index eq 0);
            # print "\tvar $var index $index ";
            my $init_v = $var_index->{$index}->{init};
            my $end_v  = $var_index->{$index}->{end};
            # warn "init_v : $init_v end_v:$end_v\n";

            my $init_ec = $data->{$eq}->{ran}->{init};
            my $end_ec  = $data->{$eq}->{ran}->{end};
            # warn "\tinit_ec : $init_ec end_ec:$end_ec\n";
            # warn "var_infoend_ec : $init_ec $init_v\n";

            
            # esta fuera del rango, asi que debe resolverse despues que otro grafo
            # la diferencia $end_v - $end_ec es la cantidad de valores fuera de rango
            # que debo analizar a ver a que otro cyclo pertence
            # warn "\t end_ec : $end_ec end_v:$end_v\n";
            if ($end_ec < $end_v) {
                # warn "end_ec :$end_ec end_v:$end_v\n";
                #busco cual es el otro grafo/cyclo que debe resoverse antes
                foreach my $other_node (@{$macro_nodes}) {
                    # warn "\t other_node ". Dumper($other_node). "\n";
                    if ($node_to_be_ordered eq $other_node) {
                        # print "\tA este nodo lo salto: " . Dumper($other_node) . "\n";
                        next;
                    }
                    
                    while($end_ec < $end_v) {
                        $end_ec++;
                        # print "$eq: $var\[$end_ec\] pertence a otro cyclo??\n" if(PRINT);
                        # warn "\tend_ec :$end_ec end_v:$end_v\n";

                        # debe resolverse $other_cycle antes de cycle
                        if(find_variable_in_graph($other_node,$var,$end_ec)) {
                            # $order->{$cycle->{name}} = $other_cycle->{name};
                            # $order->{$other_cycle->{name}} = $cycle->{name};
                            # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                            push @{$order}, $node_to_be_ordered->{name} . " -> " . $other_node->{name};
                            # print "\t1debe resolverse: " . $other_node->{name} . " antes de:" . $node_to_be_ordered->{name} . "\n" if (PRINT);
                        }

                    }

                }
            }
            warn "\t init_v : $init_v init_ec:$init_ec\n";
            if ($init_v < $init_ec) {

                foreach my $other_cycle (@{$macro_nodes}) {
                    next if ($node_to_be_ordered eq $other_cycle);
                    while($init_v < $init_ec) {
                        $init_ec--;
                        # print "$eq: $var\[$init_ec\] pertence a otro cyclo??\n" if(PRINT);
                        # warn "end_ec :$end_ec end_v:$end_v\n";
                        
                        # debe resolverse $other_cycle antes de cycle
                        if(find_variable_in_graph($other_cycle,$var,$init_ec)) {
                            # $order->{$cycle->{name}} = $other_cycle->{name};
                            # $order->{$other_cycle->{name}} = $cycle->{name};
                            # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                            push @{$order}, $node_to_be_ordered->{name} . " -> " . $other_cycle->{name};
                            # print "\t2debe resolverse: " . $other_cycle->{name} . " antes de:" . $node_to_be_ordered->{name}. "\n" if (PRINT);
                        }
                    }

                }
            }
        }
    }
    else {
        # por ahora en este caso no hago nada
    }

}

# var_info => {
#     a => [ N ],
#     b => [ N, 2 ],
#     c => ""
# } 
sub sort_macro_node_without_cycle {
    my %args = (
        eq            => undef,
        var           => undef,
        node_to_be_ordered => undef,
        macro_nodes   => undef,
        date          => undef,
        order         => undef,
        @_,
    );
    my $eq          = $args{eq};
    my $var         = $args{var};
    my $node_to_be_ordered = $args{node_to_be_ordered};
    my $macro_nodes = $args{macro_nodes};
    my $data        = $args{data};
    my $order       = $args{order};
    
    my $data_vars = $data->{$eq}->{var_info};
    my $var_info_var = $data_vars->{$var};print "var_info_var: " . Dumper($var_info_var);

    if ($var_info_var) {
        foreach my $index (@{$var_info_var}) {
            print " smnoc var $var index es $index \n";

            foreach my $other_cycle (@{$macro_nodes}) {
                next if ($node_to_be_ordered eq $other_cycle);
                # print "sort_macro_node_without_cycle other_cycle:". Dumper($other_cycle);
                print "smnoc find_variable_in_graph other_cycle:". Dumper($other_cycle) . "\n";
                    # print "$eq: $var\[$init_ec\] pertence a otro cyclo??\n" if(PRINT);
                    # warn "end_ec :$end_ec end_v:$end_v\n";
                    
                # debe resolverse $other_cycle antes de cycle
                if(find_variable_in_graph($other_cycle,$var,$index)) {
                    # print "si hay\n\n\n\n\n";
                    # $order->{$cycle->{name}} = $other_cycle->{name};
                    # $order->{$other_cycle->{name}} = $cycle->{name};
                    # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                    push @{$order}, $node_to_be_ordered->{name} . " -> " . $other_cycle->{name};
                    print "smnoc debe resolverse: " . $other_cycle->{name} . " antes de:" . $node_to_be_ordered->{name}. "\n" if (PRINT); 
                }
            }
            print "\n";
        }
    } else {
        foreach my $other_cycle (@{$macro_nodes}) {
            next if ($node_to_be_ordered eq $other_cycle);
            # print "sort_macro_node_without_cycle other_cycle:". Dumper($other_cycle);
            print "smnoc find_variable_in_graph other_cycle:". Dumper($other_cycle) . "\n";
                # print "$eq: $var\[$init_ec\] pertence a otro cyclo??\n" if(PRINT);
                # warn "end_ec :$end_ec end_v:$end_v\n";
                
            # debe resolverse $other_cycle antes de cycle
            if(find_variable_in_graph($other_cycle,$var)) {
                # print "si hay\n\n\n\n\n";
                # $order->{$cycle->{name}} = $other_cycle->{name};
                # $order->{$other_cycle->{name}} = $cycle->{name};
                # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                push @{$order}, $node_to_be_ordered->{name} . " -> " . $other_cycle->{name};
                print "smnoc debe resolverse: " . $other_cycle->{name} . " antes de:" . $node_to_be_ordered->{name}. "\n" if (PRINT); 
            }
        }
    }

}

1;