use strict;
use warnings;
use Data::Dumper;
use Graph::Undirected;
use constant N => 10;
use Scalar::Util 'looks_like_number';  
use Exporter qw(import);
our @EXPORT_OK = qw( find_variable_in_graph );
use constant DEBUG => 0;


# my $graph1  = {
        #   'ran' => '',
        #   'name' => 'a9,b9,fn,gn',
        #   'var_info' => {
        #                   'b' => [
        #                            9
        #                          ],
        #                   'a' => [
        #                            9
        #                          ]
        #                 },
        #   'equations' => [
        #                    'fn',
        #                    'gn'
        #                  ]
        # };


sub find_variable_in_graph {
    my $graph = shift;
    my $variable = shift;
    my $index = shift;

    # warn "\tfind_variable_in_graph graph: " . Dumper($graph);
    # warn "\tfind_variable_in_graph variable: " . Dumper($variable);
    # warn "\tfind_variable_in_graph index: " . Dumper($index);

    my $var_info = $graph->{var_info};

    # el grafo tiene for y la info esta en rango
    if ($graph->{ran}) { 

        # debe tener indice xq estoy buscando en un grafo que tiene for
        # si busco c, no tiene indice y sale de aca retornando 0
        if ($index) {

            my $init = $graph->{ran}->{init};
            my $end  = $graph->{ran}->{end};
            # print "ARRAY ". Dumper($graph->{ran}) . "\n";
            my $min = ($init < $end ? $init : $end);
            my $max = ($init > $end ? $init : $end);
            # print "min: $min max: $max\n";

            if ($index >= $min && $index <= $max) {
                # print "$index >= $min $index <= $max\n";
                return 1;
            } 

        }

    }
    # warn "\tfind_variable_in_graph var_info: " . Dumper($var_info);
    # el grafo no tiene for la info esta las variables
    # print "ref var_info: " . ref $var_info;
    elsif ($graph->{ran} eq '') {

        foreach my $var (keys %{$var_info}) {
            if ($var eq $variable) {

                # el caso de c no tiene indice
                return 1 unless ($index);

                my $var_info = $var_info->{$var};

                    foreach my $ar (@{$var_info}) {
                        # print "HASH ar $ar index $index\n";
                        if ($ar eq $index) {
                            return 1;
                        }
                    }
            }

        }
    }
    else {
        die "ERROR";
    }

    return 0;
}

1;