use strict;
use warnings;
use Data::Dumper;
use Graph::Undirected;
use constant M => 10;
use constant PRINT => 1;
use build_graph2 qw(:build_graph);
use util qw(:find_variable_in_graph);
use Array::Utils qw(:all);

# a[N], b[N]
# for i in 1:N-1 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]-a[i+1]=5;  //gi
# end for;

# a[N]-b[N]=8;  //fn
# a[N]+b[N]=5;  //gn

 our $init_data1 = {
    fn => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var => {
            # a => [ {init => N, end  => N},{init => 3, end  => 3} ],
            # a => [ {init => N, end  => N} ],
            # b => [ {init => N, end  => N} ]
            a => [ M ],
            b => [ M ]
        } 
    },
    gn => {
        ran => "",
        var => {
            a => [ M ],
            b => [ M ]
        } 
    },
    fi => {
        ran => { # rango del for
            init => 1,
            end  => M-1,
            next => 1  # que el siguiente valor es el actual mas next, es decir, 1
        },
        var => {
            a => "", # esto indica que tiene el mismo rango del for
            b => "", # esto indica que tiene el mismo rango del for
        }, 
    },
    gi => {
        ran => {
            init => 1,
            end  => M-1,
            next => 1 
        },
        var => {
            a => {
                1 => {#i+1 aca nos esta diciendo q a[i] debe resolverse despues que a[i+1]
                    init => 2,
                    end  => M,
                    next => 1
                }
            },
            b => ""
        }, 
    },
};

# a[M], b[M], c
# for i in 1:M-2 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]-a[i+1]=5;  //gi
# end for;
#
# a[M-1]-b[M-1]=8;  //fn
# a[M-1]+b[M-1]=5;  //gn
#
# a[M] = 22             //h1
# a[M] + b[M] + c = 22  //h2
# c = 10                //h3

 our $init_data2 = {
    fi => {
        ran => { # rango del for
            init => 1,
            end  => M-2,
            next => 1  # que el siguiente valor es el actual mas next, es decir, 1
        },
        var => {
            a => "", # esto indica que tiene el mismo rango del for
            b => "", # esto indica que tiene el mismo rango del for
        }, 
    },
    gi => {
        ran => {
            init => 1,
            end  => M-2,
            next => 1 
        },
        var => {
            a => { # este es el 1er caso de ordered_external_macro_node, cuando var_info es HASH
                1 => {#i+1 aca nos esta diciendo q a[i] debe resolverse despues que a[i+1]
                    init => 2,
                    end  => M-1,
                    next => 1
                }
            },
            b => ""
        }, 
    },
    fn => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var => {
            a => [ M-1 ], # este es el 2do caso de ordered_external_macro_node, cuando var_info es ARRAY
            b => [ M-1 ]
        } 
    },
    gn => {
        ran => "",
        var => {
            a => [ M-1 ],
            b => [ M-1 ]
        } 
    },
    h1 => {
        ran => "",# si el rango es vacio es que no estas dentro de un for
        var => {
            a => [ M ],
        } 
    },
    h2 => {
        ran => "",
        var => {
            a => [ M ],
            b => [ M ],
            c => ""
        } 
    },
    h3 => {
        ran => "",
        var => {
            c => ""
        } 
    },
};

# para cada variable me guarda en que funcion esta y en que rango de indice en dicha fc
our $var_fc = {
    a => {
        "1toN-1" => {
            fcs => ["f","g"],
            next => "+1",
        },
        "NtoN"      => {
            fcs  => ["fn","gn"],
            next => "",
        }
    },
    b => {
        "1toN-1" => {
            fcs  => ["f","g"],
            next => "+1"
        },
        "NtoN"      => {
            fcs  => ["fn","gn"],
            next => "",
        }
    }
};

our $ran = {
    1 => {
        ran => {
            min => 1,
            max => N-1,
            var => ["ai","bi"],
            fcs => ["fi","gi"],
        }
    },
    2 => {
        ran => {
            min => N,
            max => N,
            var => ["an","bn"],
            fcs => ["fn","gn"],
        },
    },
};

our $max_min_ran = {
    fi => {
        a => {
            min => 1,
            max => N-1,
        },
        b => {
            min => 1,
            max => N-1,
        },
    },
    gi => {
        a => {
            min => 1,
            max => N-1,
        },
        b => {
            min => 1,
            max => N-1,
        },
    },
    fn => {
        a => {
            min => N,
            max => N,
        },
        b => {
            min => N,
            max => N,
        },
    },
    gn => {
        a => {
            min => N,
            max => N,
        },
        b => {
            min => N,
            max => N,
        },
    },
};


# my $new_var_to_old_vars = {
#     fi => $init_data->{fi},
#     gi => $init_data->{gi},
#     fn => $init_data->{fn},
#     gn => $init_data->{gn},
# };

&main();

sub main {

    # warn Dumper($data);
    my $init_data = $init_data2;
    my $data = build_graph($init_data);
    my $graph = $data->{graph};
    my $graph_info = $data->{graph_info};

    # obtengo la cantidad de indices que tiene c/ variable
    # my $amount_indices = get_amount_indices($init_data);
    # print Dumper($amount_indices);
    # $amount_indices = {'i+1' => 1,'i' => 4 };

    # obtengo todas los nodos del grafo
    # my @all_nodes = $graph->vertices;
    # @all_nodes = (fi,gi,fn,gn,ai,bi,an,bn);

    my $all_macro_node = get_macro_node($graph, $init_data, $graph_info);
    # warn "all_macro_node: " . Dumper($all_macro_node) . "\n";

    my @internal_macro_node_ordered;
    # ordeno internamente c/u de los macro node
    foreach my $mn (@{$all_macro_node}) {
        # warn "macro node: " . Dumper($mn) . "\n";
        my $mn_ordered = resolve_macro_node($mn, $init_data, $graph_info);
        $mn_ordered->{name} = join(',', @{$mn});

        push @internal_macro_node_ordered, $mn_ordered;
    }

    my $ordered_graph = ordered_external_macro_node(\@internal_macro_node_ordered, $init_data);

    # warn "internal_macro_node_ordered: " . Dumper(@internal_macro_node_ordered) . "\n";

    warn "ordered_graph: " . Dumper($ordered_graph) . "\n";
    
    return;




    # my $all_cycles;
    # my $i=1;
    # my @ordered_inside_cycle;
    # while (my @cycle_nodes = $graph->find_a_cycle) {
    #     # warn "Ciclo: " . Dumper(@cycle) . "\n";

    #     $graph = $graph->delete_cycle(@cycle_nodes);
    #     my $cycle_ordered = resolve_macro_node(\@cycle_nodes, $init_data, $graph_info);
    #     $cycle_ordered->{name} = $i;

    #     push @ordered_inside_cycle, $cycle_ordered;
    #     $i++;
    # }


    # warn "ordered_inside_cycle: " . Dumper(@ordered_inside_cycle) . "\n";

    # my $ordered_graphs = ordered_external_macro_node(\@ordered_inside_cycle, $init_data);

}

# devuelve todos los macro nodos
# si estan dentro de un ciclo es un macronodo
# si se puede causalizar es un macronodo
sub get_macro_node {
    my $graph = shift;
    my $data = shift;
    my $graph_info = shift;

    my @macro_node;
    while (my @cycle_nodes = $graph->find_a_cycle) {
        # @cycle_nodes = sort @cycle_nodes;
        my @cn = sort @cycle_nodes;
        # warn "Ciclo: " . Dumper(@cn) . "\n";
        push @macro_node, \@cn;

        $graph = $graph->delete_cycle(@cycle_nodes);
    }

    my @vertices = $graph->vertices;
    foreach my $v (@vertices) {
        if ($graph->degree($v) == 1) {
            # print "v es $v\n";

            my @successors = $graph->successors($v);
            # como es de grado 1 el vertice solo tiene un sucesor
            my $v2 = shift(@successors);
            # print " successors: " . $v2 ." \n\n";
            my @node = ($v,$v2);
            @node = sort(@node);
            push @macro_node, \@node;
            # push @macro_node, [$v, $v2];
            $graph->delete_edge($v,$v2);
            $graph->delete_vertex($v,$v2);
        }
    }

    # print "\nmacro_node: " . Dumper(@macro_node);

    return \@macro_node;
}

# tengo que recorrer cada una de las ecuaciones y busco en los extremos si alguna 
# variable a la que hace referencia no esta dentro del ciclo
sub ordered_external_macro_node {
    my $ordered_inside_cycle = shift;
    my $data = shift;

    warn "ordered_inside_cycle: " . Dumper(@{$ordered_inside_cycle});
    my $count_cycles = @{$ordered_inside_cycle};
    # warn "count_cycles: $count_cycles";

    my @order;
    foreach my $cycle (@{$ordered_inside_cycle}) {

    print "#####################Analizando macro node: " . Dumper($cycle);

        foreach my $eq (@{$cycle->{equations}}) {
            print "\n\n\nAnalizando eq: $eq \n";

            my $vars = $data->{$eq}->{var};
            foreach my $var (keys %{$vars}) {
                my $var_info = $vars->{$var};
                print "\tAnalizando var: $var \n";
                # print "\n\nAnalizando eq: $eq var_info:" .Dumper($var_info) . "\n";
                # es una variable con i, v[i] esta dentro del ciclo
                # no hace falta chequearlo
                # next unless($var_info); 
                print "\tvar: $var tiene var info: " . Dumper ($var_info ). " ref: " . ref($var_info) . "\n";

                # si es un hash es xq es un i+1, i-1, etc. distinto a i 
                if ((ref $var_info) eq 'HASH') {
                    # warn "hash var_info: " . Dumper($var_info) . "\n";
                    # print "\n\n HASH eq: $eq var_info:" . Dumper($var_info) . "\n";

                    # recorro los indices, normalmente solo tiene un indice 
                    # del tipo i+1 o i-1
                    foreach my $index (keys %{$var_info}) {
                        # warn Dumper($data->{$eq}->{var}->{$var});
                        my $init_v = $data->{$eq}->{var}->{$var}->{$index}->{init};
                        my $end_v  = $data->{$eq}->{var}->{$var}->{$index}->{end};
                        # warn "init_v : $init_v end_v:$end_v\n";

                        my $init_ec = $data->{$eq}->{ran}->{init};
                        my $end_ec = $data->{$eq}->{ran}->{end};
                        # warn "init_ec : $init_ec end_ec:$end_ec\n";
                        # warn "var_infoend_ec : $init_ec $init_v\n";

                        
                        # esta fuera del rango, asi que debe resolverse despues que otro grafo
                        # la diferencia $end_v - $end_ec es la cantidad de valores fuera de rango
                        # que debo analizar a ver a que otro cyclo pertence
                        if ($end_ec < $end_v) {
                            # warn "end_ec :$end_ec end_v:$end_v\n";
                            #busco cual es el otro grafo/cyclo que debe resoverse antes
                            foreach my $other_cycle (@{$ordered_inside_cycle}) {
                                next if ($cycle eq $other_cycle);
                                while($end_ec < $end_v) {
                                    $end_ec++;
                                    # print "$eq: $var\[$end_ec\] pertence a otro cyclo??\n" if(PRINT);
                                    # warn "end_ec :$end_ec end_v:$end_v\n";

                                    # debe resolverse $other_cycle antes de cycle
                                    if(find_variable_in_graph($other_cycle,$var,$end_ec)) {
                                        # $order->{$cycle->{name}} = $other_cycle->{name};
                                        # $order->{$other_cycle->{name}} = $cycle->{name};
                                        # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                                        push @order, $cycle->{name} . " -> " . $other_cycle->{name};
                                        print "1debe resolverse: " . $other_cycle->{name} . " antes de:" . $cycle->{name} . "\n" if (PRINT);
                                    }

                                }

                            }
                        }
                        if ($init_v < $init_ec) {

                            foreach my $other_cycle (@{$ordered_inside_cycle}) {
                                next if ($cycle eq $other_cycle);
                                while($init_v < $init_ec) {
                                    $init_ec--;
                                    # print "$eq: $var\[$init_ec\] pertence a otro cyclo??\n" if(PRINT);
                                    # warn "end_ec :$end_ec end_v:$end_v\n";
                                    
                                    # debe resolverse $other_cycle antes de cycle
                                    if(find_variable_in_graph($other_cycle,$var,$init_ec)) {
                                        # $order->{$cycle->{name}} = $other_cycle->{name};
                                        # $order->{$other_cycle->{name}} = $cycle->{name};
                                        # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                                        push @order, $cycle->{name} . " -> " . $other_cycle->{name};
                                        print "2debe resolverse: " . $other_cycle->{name} . " antes de:" . $cycle->{name}. "\n" if (PRINT);
                                    }
                                }

                            }
                        }
                    }
                }
                # si es array es que esta fuera de un for, pero que tiene variables tipo: a[N], a[5]
                elsif(ref $var_info eq 'ARRAY') {
                    # warn "ARRAY var $var var_info: " . Dumper($var_info) . "\n";
                    # warn "a este ciclo lo analizamos despues: " . Dumper($cycle);
                    # print "ARRAY var_info:" . Dumper($var_info) . "\n";
                    # print "\tvar es: $var\n";
                    if ($var_info) {
                        # print "\t\tif var es: $var eq $eq\n";
                        foreach my $index (@{$var_info}) {
                            print " var $var i es $index \n";

                            foreach my $other_cycle (@{$ordered_inside_cycle}) {
                                next if ($cycle eq $other_cycle);
                                # print "other_cycle:". Dumper($other_cycle);
                                    # print "$eq: $var\[$init_ec\] pertence a otro cyclo??\n" if(PRINT);
                                    # warn "end_ec :$end_ec end_v:$end_v\n";
                                    
                                # debe resolverse $other_cycle antes de cycle
                                if(find_variable_in_graph($other_cycle,$var,$index)) {
                                    # print "si hay\n\n\n\n\n";
                                    # $order->{$cycle->{name}} = $other_cycle->{name};
                                    # $order->{$other_cycle->{name}} = $cycle->{name};
                                    # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                                    push @order, $cycle->{name} . " -> " . $other_cycle->{name};
                                    print "3debe resolverse: " . $other_cycle->{name} . " antes de:" . $cycle->{name}. "\n" if (PRINT); 
                                }
                            }
                        }
                    }
                }
                #     variables  => {
                #       'a' => [ 10 ],
                #       'b' => [ 10 ],
                #       'c' => [ ],
                #     }
                else {
                    my $ran = $data->{$eq}->{ran};
                    # si tiene ran es el caso que esta dentro de un for
                    if ($ran) {
                        print "Tiene ran eq: $eq var $var\n";
                    }
                    # sino tiene ran es el caso de la variable c, no tiene index
                    else {
                        # print "\t\telse var es: $var\n";
                        foreach my $other_cycle (@{$ordered_inside_cycle}) {
                            next if ($cycle eq $other_cycle);
                            print "otro macro node:". Dumper($other_cycle);
                                # print "$eq: $var\[$init_ec\] pertence a otro cyclo??\n" if(PRINT);
                                # warn "end_ec :$end_ec end_v:$end_v\n";
                                
                            # debe resolverse $other_cycle antes de cycle
                            if(find_variable_in_graph($other_cycle,$var)) {
                                # print "si hay\n\n\n\n\n";
                                # $order->{$cycle->{name}} = $other_cycle->{name};
                                # $order->{$other_cycle->{name}} = $cycle->{name};
                                # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                                push @order, $cycle->{name} . " -> " . $other_cycle->{name};
                                print "4debe resolverse: " . $other_cycle->{name} . " antes de:" . $cycle->{name}. "\n" if (PRINT); 
                            }
                        }
                    }

                }
                

            }

        }
    }

    # warn "ordered_inside_cycle: " . Dumper($ordered_inside_cycle);
    # warn "Order: " . Dumper($order);
    return \@order;

}

sub resolve_macro_node {
    my $cycle_nodes = shift;
    my $data = shift;
    my $graph_info = shift;
    my $result;

    my @all_equations = keys %{$graph_info->{eqs}};
    my @all_variables = keys %{$graph_info->{vars}};

    my @equations = intersect(@all_equations, @{$cycle_nodes});
    my @variables = intersect(@all_variables, @{$cycle_nodes});


    # warn "equations: " . Dumper(@equations);
    # warn "variables: " . Dumper(@variables);

    my $val_index = 0;

    my $ran_eq = $data->{$equations[0]}->{ran};

    my @origin_vars;
    foreach my $v (@variables) {
        push @origin_vars, $graph_info->{vars}->{$v}; 
    }

    my $ordered_ran;
    my $ordered_variables;

    # me fijo si las funciones estan dentro de un for
    if ($ran_eq) {
        my $init;
        my $end;
        my $next;
        foreach my $e (@equations) {

            foreach my $v (@variables) {
                my $real_var = $graph_info->{vars}->{$v};
                # print "real_var $v: $real_var\n";
                my $diff_index = $data->{$e}->{var}->{$real_var};
                # my $ran_eq = $data->{$e}->{ran}; # esto me dice si la eq esta dentro de un for
                
                if ($diff_index) {
                    # print "ran_eq : " . Dumper($ran_eq) . " \n";
                    # print "diff_index $e $v $real_var: " . Dumper($diff_index) . " \n";

                    foreach my $val (keys %{$diff_index}) {
                        # print "diff_index $e $v $real_var val_key $val_index: \n";

                        if ($val_index > 0) {
                            die "El mismo for no puede contener variables con indices < y > que i" if ($val < 0);

                        } 
                        elsif ($val_index < 0) {
                            die "El mismo for no puede contener variables con indices < y > que i" if ($val > 0);
                        } 
                        else {
                            $val_index = $val;
                        }

                    }
                    if ($val_index > 0) {
                        $init = $ran_eq->{end};
                        $end  = $ran_eq->{init};
                        $next = -1;

                    } 
                    else {
                        $init = $ran_eq->{init};
                        $end  = $ran_eq->{end};
                        $next = 1;
                    }

                }
            }
        }

        $ordered_ran = {
            init => $init,
            end  => $end,
            next => $next,  
        };

        $ordered_variables = \@origin_vars;

    } 
    else {

        # my $real_variables;
        foreach my $e (@equations) {
            # print "\t\tecuacion: $e\n";
            foreach my $v (@variables) {
                my $real_var = $graph_info->{vars}->{$v};
                # print "real_var $v: $real_var\n";
                my $indices = $data->{$e}->{var}->{$real_var};
                # print "indices:" . Dumper($indices) ."\n";
                my @vars;
                if ($indices) {
                    foreach my $ind (@{$indices}) {
                        # print "ind:" . Dumper($ind) ."\n";
                        push @vars, $ind;
                    }
                }

                $ordered_variables->{$real_var} = \@vars;

            }
        }

        $ordered_ran = "";
    }

    my $ordered_graph = {
        equations  => \@equations,
        variables  => $ordered_variables,
        ran        => $ordered_ran 
    };
    
    # print "ordered_graph: " . Dumper($ordered_graph);

    return $ordered_graph;

}

# output
# my $causalized1 = {
#     equation   => [fn,gn]
#     variables  => {
#       'a' => [ 10 ],
#       'b' => [ 10 ]
#     }
#     ran        => "",
# }
# my $causalized2 = {
#     equation   => [fi,gi]
#     variables  => [a,b]
#     ran        => {
#         init => N-1,
#         end  => 1,
#         next => -1,   
#     },
# }

#la condicion que voy a pedir es que las variables aparezcan varias veces pero llamando a una mayor o menor, no a ambas
#es decir, que si tengo a(i),a(i+1) en un ciclo que esta en un for, no puedo tener a a(i-1)
#la siguiente funcion chequea eso
sub check_index_var {

}


# cuando un for tiene una variable que hace referencia al siguiente indice, por ej si tiene a(i) y a(i+1), esta funcion toma los extremos de 
# del indice y se fija si las siguiente funciones y ecuaciones que necesita existen:
#   a[i]+b[i]-a[i+1]=5;  //g for i in [1,N-1] 
# para el anterior debo buscar en que otras ecuaciones aparece a[N](para cuando i vale N-1, en este caso tengo que a[i+1] con N-1 es a[N-1+1] = a[N])
# y hacer que estas otras funciones esten resueltas antes
sub analize_border_index {

}

sub only_one_index {

}


# Ejemplo 1: #####################################################
# input
# model test  
#   parameter Integer N=5;
#   Real a[N];
#   Real b[N];
# equation

# a[N], b[N]
# for i in 1:N-1 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]-a[i+1]=5;  //gi
# end for;

# a[N]-b[N]=8;  //fn
# a[N]+b[N]=5;  //gn

# my $graph = {
#     fi => {
#       ran => ([1,4],i)
#       var => {
#               a => ([1,4],i),([2,5],i+1),
#               b => ([1,4],i)
#       } 
#     },
#     gi => {
#       ran => ([1,4],i),
#       var => {
#               a => ([1,4],i),
#               b => ([1,4],i)
#       } 
#     },
#     fn => {
#       ran => [],
#       var => {
#               a => ([5,5]),
#               b => ([5,5])
#       } 
#     },
#     gn => {
#       ran => [],
#       var => {
#               a => ([5,5]),
#               b => ([5,5])
#       } 
#     }
# }


# output
# my $causalized1 = {
#     equation   => (fn,gn)
#     variables  => (a,b)
#     ran        => {(N,N)},
#     ran        => {
#         init => N,
#         end  => N,
#         next => "",   
#     },
# }
# my $causalized2 = {
#     equation   => (f,g)
#     variables  => (a,b)
#     ran        => {
#         init => N-1,
#         end  => 1,
#         next => -1,   
#     },
# }


# my $list_causalize = {
#    1 => $causalized1,
#    2 => $causalized2
# }
##################################################################

# Ejemplo 2: #####################################################
# input
# model Ejemplo
#   Real a[10],b[10],c[10];
# equation
#   for i in 1:10 loop
#       a[i]*b[i]=1;        //f
#       a[i]+b[i]^2=0;      //g
#   end for;
#     for i in 1:9 loop
#       c[i]=a[i+1]+3*b[i]; //h
#     end for;
#     c[10]=3*b[10];        //j
# end Ejemplo;

# output
# my $causalized1 = {
#     equation   => (f,g)
#     variables  => (a,b)
#     ran        => {(1,10)}, //rango: el orden dice inicio,fin
#     order      => { 1 => {(1,10),(i,i+1)} }
# }
# my $causalized2 = {
#     equation   => (h)
#     variables  => (c)
#     ran        => {(1,10)}, //rango: el orden dice inicio,fin
#     order      => { 1 => {(1,10),(i,i+1)} }
# }
# my $list_causalize = {
#    1 => $causalized1,
#    2 => $causalized2
# }
#
# causalized tiene un grafo en particular, tiene:
# ecuation y variables: son las ecuaciones y variables que deben resolverse juntas
# ran: es el rango en el que debe resolverse 
# order: es el orden de como debe resolverse el rango tiene la forma 
# 1 => {(initrang, finran), (index, como debe modificarse el index)}
# 2 => {(initrang, finran), (index, como debe modificarse el index)}
# list_causalize: orden en que debe resolverse c/u de los grafos vectoriales
##################################################################

# Ejemplo 3: #####################################################
# input
# model Test
#   Real a[N],b[N],c;
# equation
#   for i in 2:8 loop
#     f: a[i]+b[i-1]=10;
#     g: b[i]*a[i]=2;
#   end for;
#     f: a[1]+b[1]=10;
#     g: b[1]*a[1]=2;
#     h: a[1]+a[2]+a[3]+a[3]+a[4]-b[8] = c;
# end Test;
# output
# my $causalized1 = {
#     equation   => (f,g)
#     variables  => (a,b)
#     ran        => {(1,1)}, //rango: el orden dice inicio,fin
#     order      => { 1 => {(1,1),(i,i)} }
# }
# my $causalized2 = {
#     equation   => (h)
#     variables  => (c)
#     ran        => {(1,10)}, //rango: el orden dice inicio,fin
#     order      => { 1 => {(1,10),(i,i+1)} }
# }
# my $list_causalize = {
#    1 => $causalized1,
#    2 => $causalized2
# }

1;