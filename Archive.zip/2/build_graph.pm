use strict;
use warnings;
use Data::Dumper;
use Graph::Undirected;
use constant N => 10;
use constant PATH_DOT => "/Users/emanuel/Documents/personal/facultad/causalize/g3.dot";
use constant PATH_PNG => "/Users/emanuel/Documents/personal/facultad/causalize/g3.png";
use Scalar::Util 'looks_like_number';  

# a[N], b[N]
# for i in 1:N-1 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]-a[i+1]=5;  //gi
# end for;

# a[N]-b[N]=8;  //fn
# a[N]+b[N]=5;  //gn
# 
our $init_data1 = {
    fn => {
        ran => "",
        var => {
            a => {
                init => N,
                end  => N
            },
            b => {
                init => N,
                end  => N
            }
        } 
    },
    gn => {
        ran => "",
        var => {
            a => {
                init => N,
                end  => N
            },
            b => {
                init => N,
                end  => N
            }
        } 
    },
    fi => {
        ran => {
            index => {
                i => {
                    init => 1,
                    end  => N-1,
                    next => "+1"
                }
            }
        },
        var => {
            a => {
                index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            },
            b => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            }
        }, 
    },
    gi => {
        ran => {
            index => {
                i => {
                    init => 1,
                    end  => N-1,
                    next => "+1"
                }
            }
        },
        var => {
            a => {
                index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                    "i+1" => {#i+1 aca nos esta diciendo q a[i] debe resolverse despues que a[i+1]
                        init => 2,
                        end  => N,
                        next => "+1"
                    }
                }
            },
            b => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            }
        }, 
    },
};


# a[N], b[N], c
# for i in 1:N-2 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]-a[i+1]=5;  //gi
# end for;

# a[N-1]-b[N-1]=8;       //fn
# a[N-1]+b[N-1]-a[N]=5;  //gn

#  a[N] = 22             //h1
#  a[N] + b[N] + c = 22  //h2
#  c = 10                //h3


our $init_data2 = {
    fi => {
        ran => {
            index => {
                i => {
                    init => 1,
                    end  => N-2,
                    next => "+1"
                }
            }
        },
        var => {
            a => {
                index => {
                    i => {
                        init => 1,
                        end  => N-2,
                        next => "+1"
                    },
                }
            },
            b => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-2,
                        next => "+1"
                    },
                }
            }
        }, 
    },
    gi => {
        ran => {
            index => {
                i => {
                    init => 1,
                    end  => N-2,
                    next => "+1"
                }
            }
        },
        var => {
            a => {
                index => {
                    i => {
                        init => 1,
                        end  => N-2,
                        next => "+1"
                    },
                    "i+1" => {#i+1 aca nos esta diciendo q a[i] debe resolverse despues que a[i+1]
                        init => 2,
                        end  => N-1,
                        next => "+1"
                    }
                }
            },
            b => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-2,
                        next => "+1"
                    },
                }
            }
        }, 
    },
    fn => {
        ran => "",
        var => {
            a => {
                init => N-1,
                end  => N-1
            },
            b => {
                init => N-1,
                end  => N-1
            }
        } 
    },
    # si ran es vacio, tengo que crear un nodo por cada valor entre init y end de c/ variable
    gn => {
        ran => "",
        var => {
            a => {
                init => N-1,
                end  => N
            },
            b => {
                init => N-1,
                end  => N-1
            }
        } 
    },
    h1 => {
        ran => "",
        var => {
            a => {
                init => N,
                end  => N
            },
        } 
    },
    h2 => {
        ran => "",
        var => {
            a => {
                init => N,
                end  => N
            },
            b => {
                init => N,
                end  => N
            },
            c => {
                init => "",
                end  => ""
            }
        } 
    },
    h3 => {
        ran => "",
        var => {
            c => {
                init => "",
                end  => ""
            },
        } 
    }
};

# a[N], b[N], c[N]
# for i in 1:N-1 loop
#   a[i]-b[i]=8;         //fi
#   a[i]+b[i]=5;         //gi
#   a[i+1]-b[i]+c[i]=8;  //hi
# end for;
#
# a[N]-b[N]=8;       //fn
# a[N]+b[N]=5;       //gn
# b[N]-c[N]=8;       //hn


our $init_data3 = {
    fi => {
        ran => {
            index => {
                i => {
                    init => 1,
                    end  => N-1,
                    next => "+1"
                }
            }
        },
        var => {
            a => {
                index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            },
            b => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            }
        }, 
    },
    gi => {
        ran => {
            index => {
                i => {
                    init => 1,
                    end  => N-1,
                    next => "+1"
                }
            }
        },
        var => {
            a => {
                index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    }
                }
            },
            b => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            }
        }, 
    },
    hi => {
        ran => {
            index => {
                i => {
                    init => 1,
                    end  => N-1,
                    next => "+1"
                }
            }
        },
        var => {
            a => {
                index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                    "i+1" => {#i+1 aca nos esta diciendo q a[i] debe resolverse despues que a[i+1]
                        init => 2,
                        end  => N,
                        next => "+1"
                    }
                }
            },
            b => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            },
            c => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            }
        }, 
    },
    fn => {
        ran => "",
        var => {
            a => {
                init => N,
                end  => N
            },
            b => {
                init => N,
                end  => N
            }
        } 
    },
    gn => {
        ran => "",
        var => {
            a => {
                init => N,
                end  => N
            },
            b => {
                init => N,
                end  => N
            }
        } 
    },
    hn => {
        ran => "",
        var => {
            b => {
                init => N,
                end  => N
            },
            c => {
                init => N,
                end  => N
            }
        } 
    },
};

&main();

sub main {

    my $graph = Graph::Undirected->new();

    my $init_data = $init_data3;

    foreach my $ec (keys %{$init_data}) {
        # $graph->add_node( name => $ec, color => 'rojo' );
        # warn "funciones: " . Dumper($ec);
        # my $vertex = {
        #     name => $ec,
        #     rank => $data->{$ec}->{ran}
        # };
        $graph->add_vertex( $ec );
        # $graph->set_vertex_attribute( $ec, $ );
        # warn "si tiene " if ($graph->has_vertex($vertex));
        # $graph->add_vertex( name => $ec, rank => $data->{$ec}->{ran} );
        # $graph->add_node( name => $ec );
        print "ec: $ec \n";
        my $all_vars;
        foreach my $var (keys %{$init_data->{$ec}->{var}}) {
            # warn "var: " . Dumper($var);
            # warn "detalle: " . Dumper($init_data->{$ec}->{var}->{$var});

            # rango de for vacio fn gn
            if (!$init_data->{$ec}->{ran}) {
                my $init = $init_data->{$ec}->{var}->{$var}->{init};
                my $end  = $init_data->{$ec}->{var}->{$var}->{end};
                # my $new_var = $var;


                if ($init && $end) {
                    looks_like_number($init);
                    looks_like_number($end);
                    # print "1init: $init\n";
                    # print "1end: $end\n";

                    while ($init <= $end) {
                        # my $new_var = $var;warn "1init: $init ";
                        # $new_var .= $init if (defined $init);
                        my $new_var = $var . $init;
                        # $new_var .= $end if (defined $init && defined $end && $init ne $end) ;
                        $all_vars->{$new_var} = $var;
                        # warn "new_var: " . Dumper($new_var);

                        $graph->add_vertex( $new_var );
                        print "\t11var: $new_var\n";
                        # print "edge: $ec - $new_var\n";
                        $graph->add_edge( $ec, $new_var );
                        $init++;
                    }
                } else {
                    my $new_var = $var;
                    $all_vars->{$new_var} = $var;
                    # warn "new_var: " . Dumper($new_var);

                    $graph->add_vertex( $new_var );
                    print "\t12var: $new_var\n";
                    # print "edge: $ec - $new_var\n";
                    $graph->add_edge( $ec, $new_var );
                }

            } else {

                my @indexes = keys %{$init_data->{$ec}->{var}->{$var}->{index}};
                if (@indexes > 1) {
                    # warn Dumper($init_data->{$ec}->{var}->{$var}->{index});
                    foreach my $i (@indexes) {
                        

                        # es el mismo indice del for
                        if (defined $init_data->{$ec}->{ran}->{index}->{$i}) {
                            # warn "indice i+1 var es: " . Dumper($init_data->{$ec}->{ran}->{index}->{$i}) ;
                            my $detail = $init_data->{$ec}->{var}->{$var}->{index}->{$i};
                            my $init = $detail->{init};
                            my $end  = $detail->{end};
                            my $new_var = $var . $init;
                            $new_var .= $end if ($init != $end) ;
                            $all_vars->{$new_var} = $var;

                            $graph->add_vertex( $new_var );
                            print "\t2var: $new_var\n";
                            # print "edge: $ec - $new_var\n";
                            $graph->add_edge( $ec, $new_var );
                        } 
                        # otro indice: i+1
                        else {

                            if($i =~ /\+/) {

                                my $detail = $init_data->{$ec}->{var}->{$var}->{index}->{$i};
                                # my $init = $detail->{init};
                                # my $end  = $detail->{end};
                                my $max_val = $detail->{end};
                                my $new_var = $var . $max_val;
                                $all_vars->{$new_var} = $var;

                                $all_vars->{$new_var} = $var;
                                $graph->add_vertex( $new_var );
                                print "\t3var: $new_var\n";
                                # print "edge: $ec - $new_var\n";
                                $graph->add_edge( $ec, $new_var );

                            } else {
                                my $min_val = $init_data->{$ec}->{var}->{$var}->{index}->{$i}->{init};
                            }

                            # warn "indice i+1 var es: " . Dumper($init_data->{$ec}->{var}) ;
                            # warn "indice i+1 var index es: " . Dumper($init_data->{$ec}->{var}->{$var}->{index}->{$i}) ;
                            # warn "indice i+1 ran es: " . Dumper($init_data->{$ec}->{ran}) ;
                        }
                    }

                } else {
                    # warn Dumper(@indexes);
                    my $i = shift(@indexes);
                    # warn "i es: $i";
                    my $detail = $init_data->{$ec}->{var}->{$var}->{index}->{$i};
                    my $init = $detail->{init};
                    my $end  = $detail->{end};
                    my $new_var = $var . $init;
                    $new_var .= $end if ($init != $end) ;
                    $all_vars->{$new_var} = $var;

                    $all_vars->{$new_var} = $var;
                    $graph->add_vertex( $new_var );
                    print "\t4var: $new_var\n";
                    # print "edge: $ec - $new_var\n";
                    $graph->add_edge( $ec, $new_var );
                }

            }
        }

    }
    # warn Dumper($graph);
    # return $graph;
    build_png($graph);

}

sub build_png {
    my $graph = shift;

    my $g = "graph G{   
        subgraph cluster0{
        label = \"Equations\"; 
        edge [style=invis];
        ";


    my @all_nodes = $graph->vertices;
    my @ec;
    my @var;
    foreach my $node (@all_nodes) {

        if ($node =~ /f/ || $node =~ /g/ || $node =~ /h/ || $node =~ /k/) {
            push @ec, $node;
        } else {
            push @var, $node;
        }
    }

    my $ecs = join ' -- ', sort @ec;
    my $vars = join ' -- ', sort @var;

    $g .= $ecs . ";\n";
    $g .= "        }
        subgraph cluster1{
        label = \"Unknowns\";
        edge [style=invis];
        ";
    $g .= $vars . ";\n";


    $g .= "        }
        edge [constraint=false];\n";

    my @all_edges = $graph->edges;
    foreach my $e (@all_edges) {
        my @e = @$e;
        my $edge = "        " . $e[0] . " -- " . $e[1] . ";\n";
        $g .= $edge;
    }
    $g .= "}";

# warn Dumper($ecs);
# warn Dumper($g);
    open( my $output_file, '>:utf8', PATH_DOT) or die "Can't open";
    print $output_file $g;
    close $output_file;

    my $command = "dot -Tpng " . PATH_DOT . " -o " . PATH_PNG;

    my $output = `$command 2>&1`;
}

        # fi -- gi -- fn -- gn;
        # a19 -- b19 -- a10 -- b10;

#         fi -- gi -- fn -- gn -- h1 -- h2 -- h3;
#         a18 -- b18 -- a9 -- b9 -- a10 -- b10 -- c;