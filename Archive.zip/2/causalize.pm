use strict;
use warnings;
# use GraphViz2;
use Data::Dumper;
use Graph::Undirected;
use constant N => 10;

# a[N], b[N]
# for i in 1:N-1 loop
#   a[i]-b[i]=8;         //f
#   a[i]+b[i]-a[i+1]=5;  //g
# end for;

# a[N]-b[N]=8;  //fn
# a[N]+b[N]=5;  //gn
# 
our $init_data = {
    fn => {
        ran => "",
        var => {
            a => {
                init => N,
                end  => N
            },
            b => {
                init => N,
                end  => N
            }
        } 
    },
    gn => {
        ran => "",
        var => {
            a => {
                init => N,
                end  => N
            },
            b => {
                init => N,
                end  => N
            }
        } 
    },
    fi => {
        ran => {
            index => {
                i => {
                    init => 1,
                    end  => N-1,
                    next => "+1"
                }
            }
        },
        var => {
            a => {
                index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            },
            b => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            }
        }, 
    },
    gi => {
        ran => {
            index => {
                i => {
                    init => 1,
                    end  => N-1,
                    next => "+1"
                }
            }
        },
        var => {
            a => {
                index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                    "i+1" => {#i+1 aca nos esta diciendo q a[i] debe resolverse despues que a[i+1]
                        init => 2,
                        end  => N,
                        next => "+1"
                    }
                }
            },
            b => {
                  index => {
                    i => {
                        init => 1,
                        end  => N-1,
                        next => "+1"
                    },
                }
            }
        }, 
    },
};

# para cada variable me dice los indices que tiene y en cada indice me dice en que funcion esta
# y como varia el indice
our $var_index = {
    a => {
        i => {
            fi => {
                init => 1,
                end  => N-1,
                next => "+1"   
            },
            gi => {
                init => 1,
                end  => N-1,
                next => "+1"   
            },
            fn => {
                init => N,
                end  => N,
                next => ""   
            },
            gn => {
                init => N,
                end  => N,
                next => ""   
            }
        },
        "i+1" => {
            gi => {
                init => 2,
                end  => N,
                next => "+1"   
            }
        },
    },
    b => {
        i => {
            fi => {
                init => 1,
                end  => N-1,
                next => "+1"   
            },
            gi => {
                init => 1,
                end  => N-1,
                next => "+1"   
            },
            fn => {
                init => N,
                end  => N,
                next => ""   
            },
            gn => {
                init => N,
                end  => N,
                next => ""   
            }
        },
    }
    # an => {
    #     i => {
    #         fn => {
    #             init => N,
    #             end  => N,
    #             next => ""   
    #         },
    #         gn => {
    #             init => N,
    #             end  => N,
    #             next => ""   
    #         }
    #     },
    # },
    # bn => {
    #     i => {
    #         fn => {
    #             init => N,
    #             end  => N,
    #             next => ""   
    #         },
    #         gn => {
    #             init => N,
    #             end  => N,
    #             next => ""   
    #         }
    #     },
    # },
};
# para cada variable me guarda en que funcion esta y en que rango de indice en dicha fc
our $var_fc = {
    a => {
        "1toN-1" => {
            fcs => ["f","g"],
            next => "+1",
        },
        "NtoN"      => {
            fcs  => ["fn","gn"],
            next => "",
        }
    },
    b => {
        "1toN-1" => {
            fcs  => ["f","g"],
            next => "+1"
        },
        "NtoN"      => {
            fcs  => ["fn","gn"],
            next => "",
        }
    }
};

our $ran = {
    1 => {
        ran => {
            min => 1,
            max => N-1,
            var => ["ai","bi"],
            fcs => ["fi","gi"],
        }
    },
    2 => {
        ran => {
            min => N,
            max => N,
            var => ["an","bn"],
            fcs => ["fn","gn"],
        },
    },
};

our $max_min_ran = {
    fi => {
        a => {
            min => 1,
            max => N-1,
        },
        b => {
            min => 1,
            max => N-1,
        },
    },
    gi => {
        a => {
            min => 1,
            max => N-1,
        },
        b => {
            min => 1,
            max => N-1,
        },
    },
    fn => {
        a => {
            min => N,
            max => N,
        },
        b => {
            min => N,
            max => N,
        },
    },
    gn => {
        a => {
            min => N,
            max => N,
        },
        b => {
            min => N,
            max => N,
        },
    },
};


my $new_var_to_old_vars = {
    fi => $init_data->{fi},
    gi => $init_data->{gi},
    fn => $init_data->{fn},
    gn => $init_data->{gn},
};

&main();

sub main {

    # warn Dumper($data);
    build_graph($init_data);

    # obtengo la cantidad de indices que tiene c/ variable
    my $amount_indices = get_amount_indices($init_data);
    # print Dumper($amount_indices);
    # $amount_indices = {'i+1' => 1,'i' => 4 };
    my $graph = build_graph($init_data);

    # obtengo todas los nodos del grafo
    my @all_nodes = $graph->vertices;
    # @all_nodes = (fi,gi,fn,gn,ai,bi,an,bn);

    my $all_cycles;
    my $i=1;
    while (my @cycle = $graph->find_a_cycle) {
        # warn "Ciclo: " . Dumper(@cycle) . "\n";
        $all_cycles->{$i++} = \@cycle;
        $graph = $graph->delete_cycle(@cycle);
    }
    # warn "Cycles: " . Dumper($cycles) . "\n";
    # tiene todos los grafos con ciclo, pero sin ordenar
    # remove_vars($all_cycles);
    $all_cycles = { '1' => ['fn','gn'], '2' => [ 'gi','fi'] };

    # para c/u de los for, analizo var x var buscando que variable aparece con mas de un indice
    # TODO: crear el metodo buil_var_index, $var_index esta definido arriba como debe ser
    # my $var_index = build_var_index

    # tiene las variables con sus indices
    my $var_with_some_index = { a => ["i","i+1"], b => ["i"] };

    # usando $var_with_some_index decido cual es el indice que debo remover y la funcion a la que corresponde
    # my $index_to_remove = get_index_to_remove;
    my $index_to_remove = ["a","i+1","gi",2,N]; # ["var","index","funcion",min_index,max_index]

    # usando $index_to_remove me fijo si el indice sube o baja, en este caso como next es "+1"
    # tengo que sube, tomo el extremo superior de a[N], es el ultimo valor que asume dentro del cyclo
    # busco en cuales otras funciones esta la variable a[N]
    my $graph2 = { info => {}, name => "graph2" }; # es otro grafo al que pertenece la variable a[N]
    my $found_var = { a => {index => N, graph => "graph2"} };

    # este va a ser el orden en el que se van a resolver los grafos
    # despues cada grafo va a tener su respectivo orden para resolverse
    my $order_graph = { 1 => "graph2" };


    apply_order($all_cycles,$index_to_remove);#ordena los grafos ya sea de los for o no, analizando los extremos 
    # quedaria asi:
    # $all_cycles = { '2' => ['fn','gn'], '1' => [ 'gi',fi']};
    

    # my $cycles; # tiene todos los grafos con ciclo, pero sin ordenar
    # foreach my $cycle (%{$all_cycles}) {
    #     causalize($cycle,$var_fc);
    # }

    # los termina de ordenar teniendo en cuenta que habia una variable a[i] que debe resolver despues que a[i+1]
    # apply_order($order_graph,$result);
    # test();
}

sub test {
    my $graph = Graph::Undirected->new();print "\n\n\n\n";
    $graph->add_vertex( 'a1' );
    $graph->add_vertex( 'b1' );
    $graph->add_vertex( 'a2' );
    $graph->add_vertex( 'b2' );
    $graph->add_vertex( 'a3' );
    $graph->add_vertex( 'b3' );
    $graph->add_vertex( 'c' );

    $graph->add_vertex( 'f1' );
    $graph->add_vertex( 'g1' );
    $graph->add_vertex( 'f2' );
    $graph->add_vertex( 'g2' );
    $graph->add_vertex( 'h1' );
    $graph->add_vertex( 'h2' );
    $graph->add_vertex( 'h3' );

    $graph->add_edge( 'f1', 'a1' );
    $graph->add_edge( 'f1', 'b1' );
    $graph->add_edge( 'g1', 'a1' );
    $graph->add_edge( 'g1', 'b1' );

    $graph->add_edge( 'g1', 'a2' );

    $graph->add_edge( 'f2', 'a2' );
    $graph->add_edge( 'f2', 'b2' );
    $graph->add_edge( 'g2', 'a2' );
    $graph->add_edge( 'g2', 'b2' );

    $graph->add_edge( 'g2', 'a3' );

    $graph->add_edge( 'h1', 'a3' );
    $graph->add_edge( 'h2', 'a3' );
    $graph->add_edge( 'h2', 'b3' );
    $graph->add_edge( 'h2', 'c' );
    $graph->add_edge( 'h3', 'c' );

    my @all_init_vertices = $graph->vertices;
    print "init vertices: " . @all_init_vertices . "\n";
    my $i = 1;
    while (my @cycle = $graph->find_a_cycle) {
        # warn "Ciclo: " . Dumper(@cycle) . "\n";
        print "ciclo $i: " . Dumper(@cycle) . "\n\n";
        $graph->delete_cycle(@cycle);

        # foreach my $node (@cycle) {
        #     $graph->delete_vertex($node);
        # }

        $i++;
    }
    my @all_edges = $graph->edges;
    print "resto edges: " . Dumper(@all_edges) . "\n";
    # print "resto de los vertices: " . Dumper($graph->vertices);
}

sub apply_order {
    my $all_cycles = shift;
    my $index_to_remove = shift;

    my $var   = @$index_to_remove[0];#a
    my $index = @$index_to_remove[1];#i+1
    my $ec    = @$index_to_remove[2];#gi
    my $result;

    my $data = $init_data->{$ec}->{var}->{$var}->{index}->{$index};
# print "var $var index $index ec: $ec data: " . Dumper($data) . "\n";
    if ($index =~ /\+1/ ) {
        # busco la variable a[i+1] con i igual al max valor que asume en la 
        # ecuacion ec(en este caso N-1) a que otro grafo pertenece
        my $max_val_var = $max_min_ran->{$ec}->{$var}->{max};# N-1
        my $val_index = get_val_index($index,$max_val_var);# N
        # busco en los otros grafos si existe a[N]

        # contiene los otros grafos distinto al grafo donde estaba i+1
        #my @other_graph = get_other_graph;
        my @all_other_graph = (['fn','gn']);

        foreach my $other_graph (@all_other_graph) {
            foreach my $e (@{$other_graph}) {
                # print "e es $e\n";
                foreach my $v (keys %{$init_data->{$e}->{var}}) {
                    # print "v es $v\n";
                    if ($v eq $var) {
                        my $init = $init_data->{$e}->{var}->{$v}->{init};
                        my $end = $init_data->{$e}->{var}->{$v}->{end};

                        if ($init <= $val_index && $val_index <= $end) {
                            # la ecuacion $ec se debe resolver despues del grafo en donde
                            # pertenece $e

                            # TODO: hacer get_key_ec toma todos los ciclo y una ecuacion 
                            # te retorna la key que le corresponde al graph donde esta la ecuacion
                            my $after = 2;#get_key_ec($all_cycles,$ec);
                            my $before = 1;# get_key_ec($all_cycles,$e);
                            $result->{$before} = $after;
                        }
                        # print "e es $e vvv es $v init $init\n";

                    }
                }


            }
        }

        # print "max_val_var " .  Dumper($max_val_var)  . " index $index val_index $val_index val_index: $val_index";
    }
# warn Dumper($result);
    return $result;

}

# hacer bien este metodo que dado un indice y un valor te devuelve el valor 
# del indice evaluado en ese valor
sub get_val_index{
    my $index = shift;
    my $val = shift;

    if($index eq "i+1" && $val == N-1) {
        # i+1 = (N-1) + 1 = N 
        return N;
    }

}

# output
# my $causalized1 = {
#     equation   => (fn,gn)
#     variables  => {
#         a => [ {index => N} ],
#         b => [ {index => N} ]
#     }
#     ran        => "",
# }
# my $causalized2 = {
#     equation   => (fi,gi)
#     variables  => (a,b)
#     ran        => {
#         init => N-1,
#         end  => 1,
#         next => -1,   
#     },
# }

sub causalize {
    my $result = shift;
    my $cycle  = shift;
    my $var_fc = shift;

    my $var_min_max = {
        a => N,
        b => N,
    };


}

sub build_graph {
    my $data = shift;

    my $graph = Graph::Undirected->new();

    foreach my $ec (keys %{$data}) {
        # $graph->add_node( name => $ec, color => 'rojo' );
        # warn "funciones: " . Dumper($ec);
        # my $vertex = {
        #     name => $ec,
        #     rank => $data->{$ec}->{ran}
        # };
        $graph->add_vertex( $ec );
        # $graph->set_vertex_attribute( $ec, $ );
        # warn "si tiene " if ($graph->has_vertex($vertex));
        # $graph->add_vertex( name => $ec, rank => $data->{$ec}->{ran} );
        # $graph->add_node( name => $ec );
        # warn "key: $ec " .  $data->{$ec}->{ran};
        foreach my $var (keys %{$data->{$ec}->{var}}) {
            # warn "var: " . Dumper($var);
            # warn "detalle: " . Dumper($data->{$ec}->{var}->{$var});
            $graph->add_vertex( $var );
            $graph->add_edge( $ec, $var );

            warn "add_edge: $ec $var \n";
        }

    }
# warn "si tiene ciclo" if ($graph->has_a_cycle);
# warn "primer ciclo: " . Dumper($graph->find_a_cycle);
# warn "segundo ciclo: " . Dumper($graph->find_a_cycle);
# warn "tercer ciclo: " . Dumper($graph->find_a_cycle);#este te devuelve nuevamente el primer ciclo

    return $graph;
#     warn Dumper($graph);
}

# esta funcion controla la cantidad de indice que tiene una variable dentro de un for
# deberia tener uno solo
sub get_amount_indices {
    my $data = shift;

    my $amount_indices;
    foreach my $ec  (keys %{$data}) {
        # me fijo que tenga ran, si ran es vacio significa que no esta dentro de un for la funcion
        if ($data->{$ec}->{ran}) {
            foreach my $var (keys %{$data->{$ec}->{var}}) {
                # warn Dumper($data->{$ec}->{var}->{$var});
                my @index = keys %{$data->{$ec}->{var}->{$var}->{index}};

                if (@index>1) {
                    # print "fc $ec var: $var tiene mas de un indice: " . Dumper(@index) . "\n";
                }
                foreach my $in (@index) {
                    if ($amount_indices->{$in}) {
                        $amount_indices->{$in}++;
                    } else {
                        $amount_indices->{$in} = 1;
                    } 
                }
            }
        }
    }

    return $amount_indices;
}

#la condicion que voy a pedir es que las variables aparezcan varias veces pero llamando a una mayor o menor, no a ambas
#es decir, que si tengo a(i),a(i+1) en un ciclo que esta en un for, no puedo tener a a(i-1)
#la siguiente funcion chequea eso
sub check_index_var {

}


# cuando un for tiene una variable que hace referencia al siguiente indice, por ej si tiene a(i) y a(i+1), esta funcion toma los extremos de 
# del indice y se fija si las siguiente funciones y ecuaciones que necesita existen:
#   a[i]+b[i]-a[i+1]=5;  //g for i in [1,N-1] 
# para el anterior debo buscar en que otras ecuaciones aparece a[N](para cuando i vale N-1, en este caso tengo que a[i+1] con N-1 es a[N-1+1] = a[N])
# y hacer que estas otras funciones esten resueltas antes
sub analize_border_index {

}

sub only_one_index {

}


# Ejemplo 1: #####################################################
# input
# model test  
#   parameter Integer N=5;
#   Real a[N];
#   Real b[N];
# equation

#   a[N]-b[N]=8;  //fn
#   a[N]+b[N]=5;  //gn

#   for i in 1:N-1 loop
#     a[i]-b[i]-a[i+1]=8; //f
#     a[i]+b[i]=5;        //g
#   end for;

# my $graph = {
#     fn => {
#       ran => [],
#       var => {
#               a => ([5,5]),
#               b => ([5,5])
#       } 
#     }
#     gn => {
#       ran => [],
#       var => {
#               a => ([5,5]),
#               b => ([5,5])
#       } 
#     }
#     f => {
#       ran => ([1,4],i)
#       var => {
#               a => ([1,4],i),([2,5],i+1),
#               b => ([1,4],i)
#       } 
#     }
#     g => {
#       ran => ([1,4],i),
#       var => {
#               a => ([1,4],i),
#               b => ([1,4],i)
#       } 
#     }
# }


# output
# my $causalized1 = {
#     equation   => (fn,gn)
#     variables  => (a,b)
#     ran        => {(N,N)},
#     ran        => {
#         init => N,
#         end  => N,
#         next => "",   
#     },
# }
# my $causalized2 = {
#     equation   => (fi,gi)
#     variables  => (a,b)
#     ran        => {
#         init => N-1,
#         end  => 1,
#         next => -1,   
#     },
# }


# my $list_causalize = {
#    1 => $causalized1,
#    2 => $causalized2
# }
##################################################################

# Ejemplo 2: #####################################################
# input
# model Ejemplo
#   Real a[10],b[10],c[10];
# equation
#   for i in 1:10 loop
#       a[i]*b[i]=1;        //f
#       a[i]+b[i]^2=0;      //g
#   end for;
#     for i in 1:9 loop
#       c[i]=a[i+1]+3*b[i]; //h
#     end for;
#     c[10]=3*b[10];        //j
# end Ejemplo;

# output
# my $causalized1 = {
#     equation   => (f,g)
#     variables  => (a,b)
#     ran        => {(1,10)}, //rango: el orden dice inicio,fin
#     order      => { 1 => {(1,10),(i,i+1)} }
# }
# my $causalized2 = {
#     equation   => (h)
#     variables  => (c)
#     ran        => {(1,10)}, //rango: el orden dice inicio,fin
#     order      => { 1 => {(1,10),(i,i+1)} }
# }
# my $list_causalize = {
#    1 => $causalized1,
#    2 => $causalized2
# }
#
# causalized tiene un grafo en particular, tiene:
# ecuation y variables: son las ecuaciones y variables que deben resolverse juntas
# ran: es el rango en el que debe resolverse 
# order: es el orden de como debe resolverse el rango tiene la forma 
# 1 => {(initrang, finran), (index, como debe modificarse el index)}
# 2 => {(initrang, finran), (index, como debe modificarse el index)}
# list_causalize: orden en que debe resolverse c/u de los grafos vectoriales
##################################################################

# Ejemplo 3: #####################################################
# input
# model Test
#   Real a[N],b[N],c;
# equation
#   for i in 2:8 loop
#     f: a[i]+b[i-1]=10;
#     g: b[i]*a[i]=2;
#   end for;
#     f: a[1]+b[1]=10;
#     g: b[1]*a[1]=2;
#     h: a[1]+a[2]+a[3]+a[3]+a[4]-b[8] = c;
# end Test;
# output
# my $causalized1 = {
#     equation   => (f,g)
#     variables  => (a,b)
#     ran        => {(1,1)}, //rango: el orden dice inicio,fin
#     order      => { 1 => {(1,1),(i,i)} }
# }
# my $causalized2 = {
#     equation   => (h)
#     variables  => (c)
#     ran        => {(1,10)}, //rango: el orden dice inicio,fin
#     order      => { 1 => {(1,10),(i,i+1)} }
# }
# my $list_causalize = {
#    1 => $causalized1,
#    2 => $causalized2
# }

1;