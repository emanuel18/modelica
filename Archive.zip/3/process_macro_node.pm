use strict;
use warnings;
use Data::Dumper;
use Graph::Undirected;
use constant M => 10;
use constant PRINT => 1;
use build_graph2 qw(:build_graph);
use util qw(:find_variable_in_graph);
use Array::Utils qw(:all);

use Exporter qw(import);
our @EXPORT_OK = qw( process_mn_with_cycle_and_index );
use constant DEBUG => 0;


our $data1 = {
    macro_nodes => [
        {
            'ran' =>  {
                'init' => 8,
                'end' => 1,
                'next' => -1
            },
            'equations' => ['fi','gi'],
            'variables' => ['a','b'],
            'name' => 'a18,b18,fi,gi'
        },
        {
            'ran' =>  "",
            'equations' => ['fn,gn'],
            'variables' => {'a' => [9],'b' => [9]},
            'name' => 'a9,b9,fn,gn'
        },
        {
            'ran' => '',
            'name' => 'a10,h1',
            'variables' => {'a' => [ 10 ]},
            'equations' => ['h1']
        }
    ],
    init_data => {
        fi => {
            ran => { # rango del for
                init => 1,
                end  => M-2,
                next => 1  # que el siguiente valor es el actual mas next, es decir, 1
            },
            var_info => {
                a => [], # esto indica que tiene el mismo rango del for
                b => [], # esto indica que tiene el mismo rango del for
            }, 
        },
        gi => {
            ran => {
                init => 1,
                end  => M-2,
                next => 1 
            },
            var_info => {
                a => { # este es el 1er caso de ordered_external_macro_node, cuando var_info es HASH
                    1 => {#i+1 aca nos esta diciendo q a[i] debe resolverse despues que a[i+1]
                        init => 2,
                        end  => M-1,
                        next => 1
                    }
                },
                b => [],
            }, 
        },
        fn => {
            ran => "",# si el rango es vacio es que no estas dentro de un for
            var_info => {
                a => [ M-1 ], # este es el 2do caso de ordered_external_macro_node, cuando var_info es ARRAY
                b => [ M-1 ]
            } 
        },
        gn => {
            ran => "",
            var_info => {
                a => [ M-1 ],
                b => [ M-1 ]
            } 
        },
        h1 => {
            ran => "",# si el rango es vacio es que no estas dentro de un for
            var_info => {
                a => [ M ],
            } 
        }
    }
};

our $data2 = {
    node_to_be_ordered => {
        'ran' => '',
        'equations' => ['h2'],
        'variables' => {'b' => [ 10]},
        'name' => 'b10,h2'
    },
    macro_nodes => (
    {
        'ran' => '',
        'equations' => ['h2'],
        'variables' => {'b' => [ 10]},
        'name' => 'b10,h2'
    },{
        'equations' => ['h2'],
        'variables' => {'a' => [10]},
        'name' => 'a10,h2',
        'ran' => ''
    },{
        'ran' => '',
        'name' => 'a10,h1',
        'variables' => {'a' => [ 10 ]},
        'equations' => ['h1']
    }
    ),
    init_data => {
        h1 => {
            ran => "",# si el rango es vacio es que no estas dentro de un for
            var_info => {
                a => [ M ],
            } 
        },
        h2 => {
            ran => "",
            var_info => {
                a => [ M ],
                b => [ M ],
                c => ""
            } 
        },
    }
};

&main();

sub main {

    # my $a = {
    #     b => "",
    #     c => []
    # };
    # if ($a->{b}) {
    #     print "b es\n";
    # }
    # if ($a->{c}){
    #     my $c = $a->{c};
    #     print "c es\n";
    #     print "arr c es\n" if @{$c};
    # }
    # foreach my $i (keys %{$a}) {
    #     print "i $i if: " . Dumper($a->{$i}) if ($a->{$i});
    # }
    my $data = $data1;
    # process_mn_with_cycle_and_index($data->{macro_nodes}, $data->{init_data});

}

# este es el caso en donde tengo una ecuacion causaliza con 
# una variable que es un que pertenece a un arreglo. Ej.: a[10]



# esta es el caso en donde lo que tengo que analizar es un macro nodo
# dentro de un for en donde un indice es del tipo i+1 o i-1
sub process_mn_with_cycle_and_index {
    my $macro_nodes = shift;
    my $data = shift;

    my @tmp_mn = @{$macro_nodes};
    my $node_to_be_ordered = shift(@tmp_mn);# tomo el primer elemento para ordenar
# print "macro_nodes:" . Dumper($macro_nodes);
    # my $var_info = shift;

    my @order;
    # warn " data: " . Dumper($data) . "\n";
    # print "\n\n HASH eq: $eq var_info:" . Dumper($var_info) . "\n";

    # recorro los indices, normalmente solo tiene un indice 
    # del tipo i+1 o i-1
    foreach my $eq (@{$node_to_be_ordered->{equations}}) {
        # print "Analizando eq: $eq \n";

        my $vars = $data->{$eq}->{var_info};
        # print "\tdata->{eq}:" . Dumper($vars) . " \n";
        foreach my $var (keys %{$vars}) {
            my $var_info = $vars->{$var};
            # print "\tAnalizando var: $var \n";
            # print "\n\nAnalizando eq: $eq var_info:" .Dumper($var_info) . "\n";
            
            # es una variable con i, v[i] esta dentro del ciclo
            # no hace falta chequearlo
            unless($var_info) {
                # print "\tA este lo salto $var\n";
                next;
            }
            
            # print "\tvar: $var tiene var info: " . Dumper ($var_info ). " ref: " . ref($var_info) . "\n";

            # si es un hash es xq es un i+1, i-1, etc. distinto a i 
            if ((ref $var_info) eq 'HASH') {
                # warn "hash var_info: " . Dumper($var_info) . "\n";
                # print "\n\n HASH eq: $eq var_info:" . Dumper($var_info) . "\n";

                # recorro los indices, normalmente solo tiene un indice 
                # del tipo i+1 o i-1
                foreach my $index (keys %{$var_info}) {
                    # print "\tvar $var index $index " .  Dumper($data->{$eq});
                    my $init_v = $data->{$eq}->{var_info}->{$var}->{$index}->{init};
                    my $end_v  = $data->{$eq}->{var_info}->{$var}->{$index}->{end};
                    # warn "init_v : $init_v end_v:$end_v\n";

                    my $init_ec = $data->{$eq}->{ran}->{init};
                    my $end_ec  = $data->{$eq}->{ran}->{end};
                    # warn "\tinit_ec : $init_ec end_ec:$end_ec\n";
                    # warn "var_infoend_ec : $init_ec $init_v\n";

                    
                    # esta fuera del rango, asi que debe resolverse despues que otro grafo
                    # la diferencia $end_v - $end_ec es la cantidad de valores fuera de rango
                    # que debo analizar a ver a que otro cyclo pertence
                    # warn "\t end_ec : $end_ec end_v:$end_v\n";
                    if ($end_ec < $end_v) {
                        # warn "end_ec :$end_ec end_v:$end_v\n";
                        #busco cual es el otro grafo/cyclo que debe resoverse antes
                        foreach my $other_node (@{$macro_nodes}) {
                            # warn "\t other_node ". Dumper($other_node). "\n";
                            if ($node_to_be_ordered eq $other_node) {
                                # print "\tA este nodo lo salto: " . Dumper($other_node) . "\n";
                                next;
                            }
                            
                            while($end_ec < $end_v) {
                                $end_ec++;
                                # print "$eq: $var\[$end_ec\] pertence a otro cyclo??\n" if(PRINT);
                                # warn "\tend_ec :$end_ec end_v:$end_v\n";

                                # debe resolverse $other_cycle antes de cycle
                                if(find_variable_in_graph($other_node,$var,$end_ec)) {
                                    # $order->{$cycle->{name}} = $other_cycle->{name};
                                    # $order->{$other_cycle->{name}} = $cycle->{name};
                                    # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                                    push @order, $node_to_be_ordered->{name} . " -> " . $other_node->{name};
                                    # print "\t1debe resolverse: " . $other_node->{name} . " antes de:" . $node_to_be_ordered->{name} . "\n" if (PRINT);
                                }

                            }

                        }
                    }
                    # warn "\t init_v : $init_v init_ec:$init_ec\n";
                    if ($init_v < $init_ec) {

                        foreach my $other_cycle (@{$macro_nodes}) {
                            next if ($node_to_be_ordered eq $other_cycle);
                            while($init_v < $init_ec) {
                                $init_ec--;
                                # print "$eq: $var\[$init_ec\] pertence a otro cyclo??\n" if(PRINT);
                                # warn "end_ec :$end_ec end_v:$end_v\n";
                                
                                # debe resolverse $other_cycle antes de cycle
                                if(find_variable_in_graph($other_cycle,$var,$init_ec)) {
                                    # $order->{$cycle->{name}} = $other_cycle->{name};
                                    # $order->{$other_cycle->{name}} = $cycle->{name};
                                    # push @{$order->{$cycle->{name}}}, $other_cycle->{name};
                                    push @order, $node_to_be_ordered->{name} . " -> " . $other_cycle->{name};
                                    # print "\t2debe resolverse: " . $other_cycle->{name} . " antes de:" . $node_to_be_ordered->{name}. "\n" if (PRINT);
                                }
                            }

                        }
                    }
                }
            }


        }

    }
    print Dumper(@order);

    return @order;
}

1;